Title: QUEUE
database name: account
table name: forsignup

for admin login:
user id: admin
user password: admin

home page link:
http://localhost/queue/project_queue/
